<h1>Architecting on AWS</h1>   -    
By Mohamed Amine ESSFALI



<center>


<h3>Here is the IP Address of this EC2 instance:</h3>
<h1>
<?php
echo $_SERVER['SERVER_ADDR'];
?>
</h1>


</center>